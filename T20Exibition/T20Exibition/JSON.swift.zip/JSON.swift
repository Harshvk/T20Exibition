class JSON{
    
    static var data : [[String : Any ]] =
        [
            [
        
                "country" : "India",
    
                "Trophies" : [
                                    [
                                    "Trophy Name" : "Ranji Trophy",
                
                                    "Teams" : [
                                                    ["Name" : "Andhra",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Assam",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Baroda",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Bengal",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Chhattisgarh",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Delhi",
                                                    "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Goa",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Gujarat",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Haryana",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Himachal Pradesh",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Hyderabad",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Jammu and Kashmir",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Maharashtra",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Mumbai",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Odisha",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Punjab",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Railways",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Rajasthan",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Saurashtra",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Services",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Tripura",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Vidarbha",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "Uttar Pradesh",
                                                     "Image" : ""
                                                    ]
                                             
                                            

                                                ]
                                    ],
                
                               
                                    [
                                    "Trophy Name" : "IPL",
                                
                                    "Teams" : [
                                        
                                                    ["Name" : "KKR",
                                                     "Image" : ""
                                                    ],
                                                    
                                                    ["Name" : "MI",
                                                     "Image" : ""
                                                    ],
                                                    ["Name" : "RPS",
                                                     "Image" : ""
                                                    ],
                                                    ["Name" : "GL",
                                                     "Image" : ""
                                                    ],
                                                    ["Name" : "SRH",
                                                     "Image" : ""
                                                    ],
                                                    ["Name" : "KXIP",
                                                     "Image" : ""
                                                    ],
                                                    ["Name" : "RR",
                                                     "Image" : ""
                                                    ],
                                                    ["Name" : "RCB",
                                                     "Image" : ""
                                                    ]

                                                ]
                                    ]
        
                            ],
                ],

                [
                    "country" : "Australia",
                
                    "Trophies" :
                
                            [
                                    [
                                        "Trophy Name" : "Big Bash League",
                    
                                        "Teams" : [
                                            
                                                    [
                                                        "Name" : "Adelaide Strikers",
                                                        "Image" : ""
                                                    ],
                                                    
                                                    [
                                                        "Name" : "Brisbane Heat",
                                                        "Image" : ""
                                                    ],
                                                    [
                                                        "Name" : "Hobart Hurricanes",
                                                        "Image" : ""
                                                    ],
                                                    [
                                                        "Name" : "Melbourne Renegades",
                                                        "Image" : ""
                                                    ],
                                                    [
                                                        "Name" : "Melbourne Stars",
                                                        "Image" : ""
                                                    ],
                                                    [
                                                        "Name" : "Perth Scorchers",
                                                        "Image" : ""
                                                    ],
                                                    [
                                                        "Name" : "Sydney Thunder",
                                                        "Image" : ""
                                                    ],
                                                    [
                                                        "Name" : "Sydney Sixers",
                                                        "Image" : ""
                                                    ],
                                                    
                                                ]
                                    ],
                                    [
                                        "Trophy Name" : "SHEFFIELD SHIELD",
                                        
                                        "Teams" : [
                                            
                                            
                                                        ["Name" : "New South Wales",
                                                         "Image" : ""
                                                        ],
                                                        ["Name" : "Victoria",
                                                         "Image" : ""
                                                        ],
                                                        ["Name" : "South Australia",
                                                         "Image" : ""
                                                        ],
                                                        ["Name" : "Queensland",
                                                         "Image" : ""
                                                        ],
                                                        ["Name" : "Western Australia",
                                                         "Image" : ""
                                                        ],
                                                        ["Name" : "Tasmania",
                                                         "Image" : ""
                                                        ],
                    
                                
                                                    ]
                
                                    ]
                            ]
    
                    ]
    ]


}
